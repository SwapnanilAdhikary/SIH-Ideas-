# ol-react
 A simple example of how to get started with OpenLayers in React

 The video on YouTube: https://www.youtube.com/watch?v=okcnlN91dC0

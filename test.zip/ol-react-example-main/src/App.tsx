import './App.css';
import OpenLayersMap from './components/OpenLayersMap';

function App() {
    return <OpenLayersMap />;
}

export default App;
